
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gsirv
 */
public class main {
    //declare our array that will call from other classes and objects
    static psychArray pArray ;

    public static void main(String[] args){
    
        //this tryblock is onyl here in case the text file is not present in relative location
        //for user convenience
    try {
        //create file object
      File myFile = new File("dead.txt");
      //createfile method
        if(myFile.createNewFile()) {
        System.out.println("File created: " + myFile.getName());
        //buffer write all data for dead.txt
        FileWriter start = new FileWriter("dead.txt");
        BufferedWriter write = new BufferedWriter(start);
        write.write("California 2011 4033");
        write.newLine();
        write.write("California 2012 3915");
        write.newLine();
        write.write("California 2013 4050");
        write.newLine();
        write.write("California 2014 4249");
        write.newLine();
        write.write("California 2015 4232");
        write.newLine();
        write.write("California 2016 4311");
        write.newLine();
        write.write("California 2017 4352");
        write.newLine();
        write.write("California 2018 4541");
        write.newLine();
        write.write("California 2019 4460");
        write.newLine();
        write.write("California 2019 4075");
        write.close();
    }
        }
    catch (IOException e) {
      System.out.println("error");
      e.printStackTrace();
    }

        //intialize scanner
        Scanner scan = new Scanner(System.in);
        //initialize pArray with psychArray constructor
        pArray = new psychArray();
        //intro
        System.out.println("Here is the current presented data...");
        System.out.println("");
        System.out.println("How would you like to modify or use this data?");
        //loop condition declaration
        int stop=0;
        
        //while loop that will continue user commands until program is finished
        while (stop == 0){
            //specified options w/ user input needed
            System.out.println("a = add | d = delete | c = calculate | f = finish");
            char stage = scan.next().charAt(0);
            //switch case for each option
            switch(stage){
                //calls addition method from psychArray with following info
                case 'a': 
                    System.out.println("What state?");
                    String state = scan.next();
                    
                    System.out.println("Which year?");
                    int year = scan.nextInt();
                    
                    System.out.println("What was the death toll");
                    double death = scan.nextDouble();

                    pArray.add(state, year, death);
                    break;
                //calls delete method from psychArray class w/ following info
                case 'd':
                    System.out.println("Which line would you like to delete?");
                    int del = scan.nextInt();
                    pArray.delete(del);
                    break;
                //calc Array method that will use data to compare the % diff of suicides from year to year
                case 'c':
                    //call calc array function
                    pArray.calcArray();
                    break;
                case 'f':
                    //finish program
                    pArray.psychFinish();
                    //change loop condition to end program
                    stop=1;
                    break;
            }
        
        }
        
        
        //pArray.add("hi", 2020, 0.0);
        
        
        
        //psychVar.psychEdit();
        //psychArray.calcArray();
        
    }
}
