
import static java.lang.reflect.Array.set;
import java.util.Arrays;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gsirv
 */
public class psychVar {
    //declare needed primitve data types ofr psychvar object
    private double death;
    private int year;
    private String state;
    
    //each psychVar gets assigned 3 variables with primitive data types
    public psychVar(String local, int year, double death) {
        this.state = local;
        this.year = year;
        this.death = death;
        
        
    }
    //some of these are not needed yet but I did use getYear for the calcArray method 
    public void setState(String s) {
        state = s;
    }
    public String getState() {
        return this.state;
    }
    
    public void setDeath(double d) {
        death = d;
    }
    public double getDeath() {
        return this.death;
    }
    
    public void setYear(int y) {
        this.year = y;
    }
    public int getYear() {
        return this.year;
    }
     
    //print psychVar into string 
    public String toString(){
        return state + " " + year + " " + death;
    }
}

