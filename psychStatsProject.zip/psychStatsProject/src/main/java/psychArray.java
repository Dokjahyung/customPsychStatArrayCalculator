
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author gsirv
 */
public class psychArray {
    //declare arrys we will use in this program
    private psychVar array[];

        //basic constructor class that will read file and store data in array[] and deathArr[]
    public psychArray() {
        int count = 0;
        String[] nums;
        
         try {
            //if file exists
                //ead in fom file
                //save to aay
            //if not exists
                //ceate new file    
           Scanner scanner = new Scanner(new File("dead.txt"));

           //While loop iterates through file and extends array index by 3 per line
           while(scanner.hasNextLine()) {
               count = count + 3;
               String line = scanner.nextLine();
               System.out.println(line);
           }
           //intialize nums array declared above
           nums = new String[count];
           //declare and initialize scan variable
           Scanner s2 = new Scanner(new File("dead.txt"));

           //For loop now assigns elements to an array of Strings (nums)
           for (int i = 0; i < count; i++) {
               //each string in between spaces is one element not a line
               nums[i] = s2.next();
           } 
           //format array to read data in organized way
           //extract data from nums for uses
           //having issues of boundaries so I am keeping these arrays with an extra cushion till I find out another way
           array = new psychVar[count/3];
           
           int j = 0;
           //parse in appropriate data or object types
           for (int i=0; i<count; i+=3) {
               array[j] = new psychVar(nums[i], Integer.parseInt(nums[i+1]), Double.parseDouble(nums[i+2]));
               j++;
            }
         }
        catch (IOException e){
            e.printStackTrace();
        }
    }

    
    //delete method 
    public void delete(int delete) {
        //declare copy array as psychVar
        psychVar arrCopy[];
        
        for(int i=0;i<this.array.length;i++){

            //if line wanted deleted found, copy elements from original array to new array 
            if (i==delete-1){
                arrCopy=new psychVar[this.array.length-1];
                //system.arraycopy takes 4 arguments (former array, starting position to copy, new array, new start of copy, length of elements)
                //this copies all elements up to line before deletion line
                System.arraycopy(this.array, 0, arrCopy, 0, i);
                //if arrcopy length - index (i) is = or greater than 0. copy this.array at position over deletion line  shifted back one to new array
                if (arrCopy.length - i >= 0) {
                    System.arraycopy(this.array, i + 1, arrCopy, i, arrCopy.length - i);
                    //store this new array beck into this.array
                    this.array = arrCopy;
                }
            }
            //need to use toString method from psaychVAr
        }
        //print array organized for user
        for (int i=0; i<this.array.length; i++){
            System.out.println(this.array[i].toString());
        }
    }
    // method add similar to delete    
    public void add(String local, int year, double death) {
        psychVar[] arrCopy = new psychVar[this.array.length+1];
        for(int j=0;j<this.array.length;j++){
            arrCopy[j]=this.array[j];
        }
        arrCopy[arrCopy.length-1] = new psychVar(local, year, death);
        this.array = arrCopy;
        for (int i=0; i<this.array.length; i++){
            System.out.println(this.array[i].toString());
        }
    }
    

    //use death stats for caluclation     
    public void calcArray () {
            double d = 0.0;
                       //scan for user year input
           Scanner input = new Scanner(System.in);
           int dyear = 0;
           //need to declare outside 
           int i;
        while (dyear != -99) {
           System.out.println("Which year's stats would you like to compare? TYPE -99 for STOP");
           //next int to be read will be the year we use to examien stats on 'dyear' = desired year
           dyear = input.nextInt();
           //make for loop to figure out which element that year's death stats are
           for (i=0; i<this.array.length; i++){
               //if year[i] == dyear, value d will = death[i]
               if (this.array[i].getYear() ==  dyear){
                   //get the exact year death stats for the user so we can get percentile
                   d = this.array[i].getDeath();
                   //print the percent value diff from average of death rates
                   //psych var 'adpy'method will do actual calculation
                   System.out.println(adpy(this.array, d));
               }
               else{
                   //System.out.println("...");
               }
           }
           }  
        }
        //calculation method for calc array
     public static String adpy(psychVar[] array,double d){
        double avg = 0;
        //initialize and declare avg value for calc
        for (int i=0; i<array.length; i++){
        avg += array[i].getDeath();//add up all deaths so that we can get avg
        }
        avg /= array.length;//finished avg calculation
        //initialize and declare percentile change for calc
        double pcnt = 0;
        //percentile is calculated
        pcnt = (d-avg)/avg*100;
        // must compare desired year stat to total avg stat
        
        //return readable percentile value for user
        return '%' + String.valueOf(pcnt);
    }

    //write data into text file once it is completed
    public void psychFinish() {
        try {
            //bufffered filewriter 
            FileWriter fw = new FileWriter("dead.txt");
            BufferedWriter bw = new BufferedWriter(fw);
            //each element gets it's own line when being re written
            for (int i=0;i<this.array.length;i++){
                bw.write(this.array[i].toString());
                bw.newLine();
            }
            //close buffered writer
            bw.close();
            //print for user that program is finished
            System.out.println("Colection successful...");
            System.out.println("rewriting text file");
        }
        catch (Exception e){
            e.getStackTrace();
        }
    }
    
}
